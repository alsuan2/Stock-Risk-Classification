# Stock Risk Classification to Support Novice Investors

A hybrid machine learning dashboard that classifies individual stocks as **Likely Low Risk**, **Moderate Risk**, or **Likely High Risk** using LSTM price forecasting, LightGBM fundamental analysis, and FinBERT sentiment analysis — presented through an interactive Streamlit interface for novice retail investors.

# Table of Contents

- [About the Project](#about-the-project)
- [Features](#features)
- [Tech Stack](#tech-stack)
- [Getting Started](#getting-started)
  - [Prerequisites](#prerequisites)
  - [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Contributors](#contributors)
- [License](#license)

# About the Project

Retail participation in equity markets has grown significantly, yet the tools available to novice investors remain primarily descriptive providing raw price data and financial ratios without AI-driven risk insights. This project addresses that gap by combining three complementary machine learning models into a single weighted risk classification system:

LSTM — 180-day autoregressive price forecasting (20% weight)
LightGBM — sector-benchmarked fundamental scoring and S&P 500 outperformance prediction (50% weight)
FinBERT — 30-day financial news sentiment classification (30% weight)

The combined score is thresholded into an interpretable risk label and displayed on an interactive Streamlit dashboard alongside each component's individual output.

> Not Financial Advice. Risk labels are model outputs, not investment recommendations.

#Features

- Enter any Yahoo Finance-supported stock ticker and receive an instant risk classification
- 180-day LSTM price forecast chart overlaid on 3 years of historical closing prices
- Sector-benchmarked fundamental score (0–100) comparing the stock against S&P 500 sector averages across 8 financial metrics
- LightGBM-predicted Outperform / Underperform label relative to the S&P 500 over the next 180 days
- FinBERT sentiment gauge and dominant sentiment label derived from the past 30 days of company news headlines
- 8 most recent news headlines displayed with per-headline sentiment colour coding
- Weighted overall risk label (Likely Low Risk / Moderate Risk / Likely High Risk)
- Real-time dashboard updates when ticker changes
- Model caching — LSTM models trained once per ticker and reloaded from disk on subsequent queries

---

# Tech Stack

- **Dashboard:** Streamlit, Plotly
- **LSTM Forecasting:** TensorFlow / Keras, NumPy, scikit-learn
- **Fundamental Analysis:** LightGBM, pandas, yfinance
- **Sentiment Analysis:** HuggingFace Transformers (ProsusAI/finbert), PyTorch
- **Data Sources:** Yahoo Finance (yfinance), Finnhub API, Wikipedia
- **Version Control:** Git & GitHub

---

# Getting Started

# Prerequisites

- Python 3.10 or higher
- pip
- A free [Finnhub API key](https://finnhub.io) — replace the key in `Dashboard.py`

# Installation

```bash
# Clone the repository
git clone https://github.com/your-username/FinalYearProject.git

# Navigate to the project folder
cd FinalYearProject

# Install dependencies
pip install -r requirements.txt
```

# Train the LightGBM model (required before first run)

```bash
python modules/LightGBM_Fundamentals_Model.py
```

This fetches S&P 500 fundamental data, builds the training dataset, trains the classifier, and saves `lightgbm_model.pkl` and `dataset/fundamentals.csv`.

---

# Usage

```bash
streamlit run Dashboard.py
```

Open the URL shown in the terminal (default: `http://localhost:8501`).

1. Enter a stock ticker in the left sidebar (e.g. `AAPL`, `TSLA`, `NVDA`)
2. Wait for the LSTM model to load or train (cached tickers load in seconds; new tickers train on first query)
3. View the risk label, forecast chart, fundamental score, and sentiment gauge

---

# Project Structure

```
FinalYearProject/
│
├── Dashboard.py                        # Main Streamlit entry point
├── lightgbm_model.pkl                  # Pre-trained LightGBM classifier
├── requirements.txt                    # Python dependencies
│
├── modules/
│   ├── LSTM_Forecasting_Model.py       # LSTM architecture, training, 180-day forecast
│   ├── LightGBM_Fundamentals_Model.py  # Fundamental scoring, S&P500 label, classifier
│   ├── FinBERT_Sentiment_Model.py      # FinBERT inference and sentiment thresholding
│   └── sp500_dataset.py                # S&P500 ticker fetcher (Wikipedia)
│
├── models/                             # Per-ticker cached LSTM models and scalers
│   ├── {ticker}_lstm_model.keras
│   ├── {ticker}_scaler.pkl
│   └── {ticker}_metrics.txt
│
├── dataset/                            # Cached training and evaluation data
│   ├── fundamentals.csv
│   ├── sp500_tickers.csv
│   └── evaluation_results.csv
│
└── test_fyp.py                         # Unit test suite (pytest)
```


# Contributors

- Suan Ali — Solo developer (COMP1682 Final Year Project, University of Greenwich)

## License

This project was developed for academic purposes as part of COMP1682 at the University of Greenwich. All data is sourced from publicly available APIs under their respective non-commercial terms of service.
